import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import {
  Activity,
  BookOpen,
  Cpu,
  Gauge,
  Lightbulb,
  Loader2,
  LogOut,
  Moon,
  Moon as MoonIcon,
  Radio,
  Sparkles,
  Sun,
  SunMedium,
  Waves,
  Zap,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

import { Button } from "@/components/ui/button";
import { recommendSensitivity, type Recommendation } from "@/lib/ai.functions";

type ConnectionState = "offline" | "connecting" | "online" | "error";

type ArduinoMessage = {
  pwm?: number;
  value?: number;
  sensitivity?: number;
  light?: number;
  lux?: number;
  ambient?: number;
  mode?: string;
  powered?: boolean;
};

type HistoryPoint = { t: number; time: string; pwm: number; ambient: number };

const WS_URL = "wss://lightcontrollerserver.onrender.com/";
const MAX_PWM = 255;
const MAX_HISTORY = 60;
const AUTH_KEY = "lumasense-auth";
const THEME_KEY = "lumasense-theme";
const CREDENTIALS = { username: "ayanka", password: "8421" };

const PRESETS = [
  { id: "night", label: "Night", icon: MoonIcon, pwm: 26, hint: "Soft glow for sleeping" },
  { id: "reading", label: "Reading", icon: BookOpen, pwm: 128, hint: "Balanced desk light" },
  { id: "work", label: "Work", icon: Cpu, pwm: 190, hint: "Bright, steady output" },
  { id: "studio", label: "Studio", icon: SunMedium, pwm: 255, hint: "Maximum brightness" },
  { id: "auto", label: "Auto", icon: Sparkles, pwm: -1, hint: "Follow ambient sensor" },
] as const;

const clamp = (value: number, min: number, max: number) => Math.min(Math.max(value, min), max);

const parseArduinoMessage = (payload: string): ArduinoMessage | null => {
  const trimmed = payload.trim();
  const numeric = Number(trimmed);

  if (Number.isFinite(numeric) && trimmed !== "") {
    return { pwm: numeric };
  }

  try {
    const parsed = JSON.parse(trimmed) as ArduinoMessage;
    return parsed && typeof parsed === "object" ? parsed : null;
  } catch {
    return null;
  }
};

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "LumaSense Arduino Light Controller" },
      {
        name: "description",
        content:
          "Sign in to control Arduino PWM light sensitivity with presets, live history charts and AI suggestions.",
      },
      { property: "og:title", content: "LumaSense Arduino Light Controller" },
      {
        property: "og:description",
        content:
          "Neumorphic dashboard with live PWM history, smart presets and AI-recommended light sensitivity.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const [authed, setAuthed] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const [theme, setTheme] = useState<"light" | "dark">("light");

  useEffect(() => {
    setHydrated(true);
    setAuthed(window.localStorage.getItem(AUTH_KEY) === "ok");
    const stored = window.localStorage.getItem(THEME_KEY);
    const initial =
      stored === "dark" || stored === "light"
        ? stored
        : window.matchMedia("(prefers-color-scheme: dark)").matches
          ? "dark"
          : "light";
    setTheme(initial);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    document.documentElement.classList.toggle("dark", theme === "dark");
    window.localStorage.setItem(THEME_KEY, theme);
  }, [theme, hydrated]);

  const toggleTheme = () => setTheme((prev) => (prev === "dark" ? "light" : "dark"));

  if (!hydrated) return <div className="min-h-screen bg-background" />;

  if (!authed) {
    return (
      <LoginScreen
        theme={theme}
        onToggleTheme={toggleTheme}
        onSuccess={() => {
          window.localStorage.setItem(AUTH_KEY, "ok");
          setAuthed(true);
        }}
      />
    );
  }

  return (
    <Dashboard
      theme={theme}
      onToggleTheme={toggleTheme}
      onSignOut={() => {
        window.localStorage.removeItem(AUTH_KEY);
        setAuthed(false);
      }}
    />
  );
}

function ThemeToggle({ theme, onToggle }: { theme: "light" | "dark"; onToggle: () => void }) {
  return (
    <Button variant="neoSoft" size="icon" onClick={onToggle} aria-label="Toggle dark mode">
      {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
    </Button>
  );
}

function LoginScreen({
  theme,
  onToggleTheme,
  onSuccess,
}: {
  theme: "light" | "dark";
  onToggleTheme: () => void;
  onSuccess: () => void;
}) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    if (
      username.trim().toLowerCase() === CREDENTIALS.username &&
      password === CREDENTIALS.password
    ) {
      setError("");
      onSuccess();
      return;
    }
    setError("Wrong username or password.");
  };

  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-4 py-10 text-foreground">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_25%_20%,var(--color-glass),transparent_35%),linear-gradient(145deg,var(--color-background),var(--color-secondary))]" />
      <div className="absolute right-6 top-6">
        <ThemeToggle theme={theme} onToggle={onToggleTheme} />
      </div>

      <form
        onSubmit={submit}
        className="neo-panel w-full max-w-sm rounded-[2.25rem] border border-glass-border p-7"
      >
        <div className="mb-6 flex items-center gap-3">
          <div className="neo-soft flex h-12 w-12 items-center justify-center rounded-full">
            <Radio className="h-5 w-5 text-primary" aria-hidden="true" />
          </div>
          <div>
            <p className="text-xs font-extrabold uppercase text-muted-foreground">LumaSense</p>
            <h1 className="font-display text-2xl font-bold">Sign in</h1>
          </div>
        </div>

        <label htmlFor="username" className="text-sm font-bold">
          Username
        </label>
        <input
          id="username"
          autoComplete="username"
          value={username}
          onChange={(event) => setUsername(event.target.value)}
          className="neo-sunken mt-2 min-h-12 w-full rounded-2xl border border-glass-border px-4 text-sm font-semibold outline-none focus:ring-2 focus:ring-ring"
          placeholder="ayanka"
        />

        <label htmlFor="password" className="mt-4 block text-sm font-bold">
          Password
        </label>
        <input
          id="password"
          type="password"
          autoComplete="current-password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          className="neo-sunken mt-2 min-h-12 w-full rounded-2xl border border-glass-border px-4 text-sm font-semibold outline-none focus:ring-2 focus:ring-ring"
          placeholder="••••"
        />

        {error ? <p className="mt-3 text-sm font-semibold text-destructive">{error}</p> : null}

        <Button type="submit" variant="neoActive" size="lg" className="mt-6 w-full">
          Enter dashboard
        </Button>
      </form>
    </main>
  );
}

function Dashboard({
  theme,
  onToggleTheme,
  onSignOut,
}: {
  theme: "light" | "dark";
  onToggleTheme: () => void;
  onSignOut: () => void;
}) {
  const socketRef = useRef<WebSocket | null>(null);
  const poweredRef = useRef(true);
  const pwmRef = useRef(128);
  const ambientRef = useRef(54);
  const [connection, setConnection] = useState<ConnectionState>("offline");
  const [pwm, setPwm] = useState(128);
  const [ambientLight, setAmbientLight] = useState(54);
  const [powered, setPowered] = useState(true);
  const [activePreset, setActivePreset] = useState<string>("reading");
  const [autoMode, setAutoMode] = useState(false);
  const [lastPacket, setLastPacket] = useState("Connecting to controller");
  const [history, setHistory] = useState<HistoryPoint[]>([]);
  const [need, setNeed] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState("");
  const [advice, setAdvice] = useState<Recommendation | null>(null);

  const askAi = useServerFn(recommendSensitivity);

  const percent = useMemo(() => Math.round((pwm / MAX_PWM) * 100), [pwm]);
  const statusLabel = {
    offline: "Offline",
    connecting: "Pairing",
    online: "Live",
    error: "Retrying",
  }[connection];

  poweredRef.current = powered;
  pwmRef.current = pwm;
  ambientRef.current = ambientLight;

  const pushHistory = (nextPwm: number, nextAmbient: number) => {
    setHistory((prev) => {
      const now = Date.now();
      const point: HistoryPoint = {
        t: now,
        time: new Date(now).toLocaleTimeString([], { minute: "2-digit", second: "2-digit" }),
        pwm: nextPwm,
        ambient: Math.round((nextAmbient / 100) * MAX_PWM),
      };
      return [...prev, point].slice(-MAX_HISTORY);
    });
  };

  const sendToArduino = (nextPwm: number, nextPowered = poweredRef.current) => {
    const socket = socketRef.current;
    if (socket?.readyState !== WebSocket.OPEN) return;

    socket.send(
      JSON.stringify({
        // Must be "set_pwm" with a "value" field — that's the exact
        // shape the Arduino sketch's string parser matches on.
        type: "set_pwm",
        value: nextPowered ? nextPwm : 0,
        percent: Math.round((nextPwm / MAX_PWM) * 100),
        powered: nextPowered,
        sentAt: Date.now(),
      }),
    );
  };

  useEffect(() => {
    let closed = false;
    let retry: ReturnType<typeof setTimeout> | null = null;
    let idle: ReturnType<typeof setTimeout> | null = null;

    const open = () => {
      if (closed) return;
      setConnection("connecting");
      const socket = new WebSocket(WS_URL);
      socketRef.current = socket;

      socket.addEventListener("open", () => {
        setConnection("online");
        setLastPacket("Handshake complete");
        sendToArduino(pwmRef.current, poweredRef.current);
        pushHistory(pwmRef.current, ambientRef.current);
        if (idle) clearTimeout(idle);
        idle = setTimeout(() => {
          setLastPacket("Connected · waiting for Arduino data");
        }, 8000);
      });

      socket.addEventListener("message", (event) => {
        const payload = typeof event.data === "string" ? event.data : "";
        const message = parseArduinoMessage(payload);
        if (!message) return;

        const incomingPwm = message.pwm ?? message.value ?? message.sensitivity;
        const incomingLight = message.light ?? message.lux ?? message.ambient;
        let nextPwm = pwmRef.current;
        let nextAmbient = ambientRef.current;

        if (typeof incomingPwm === "number" && Number.isFinite(incomingPwm)) {
          nextPwm = Math.round(clamp(incomingPwm, 0, MAX_PWM));
          setPwm(nextPwm);
        }

        if (typeof incomingLight === "number" && Number.isFinite(incomingLight)) {
          nextAmbient = Math.round(clamp(incomingLight, 0, 100));
          setAmbientLight(nextAmbient);
        }

        if (typeof message.powered === "boolean") setPowered(message.powered);

        if (idle) clearTimeout(idle);
        pushHistory(nextPwm, nextAmbient);
        setLastPacket("Arduino packet received");
      });

      socket.addEventListener("close", () => {
        socketRef.current = null;
        if (closed) return;
        setConnection("error");
        setLastPacket("Reconnecting to controller");
        retry = setTimeout(open, 2500);
      });

      socket.addEventListener("error", () => {
        setConnection("error");
        setLastPacket("Controller unreachable");
      });
    };

    open();

    return () => {
      closed = true;
      if (retry) clearTimeout(retry);
      if (idle) clearTimeout(idle);
      socketRef.current?.close();
      socketRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const applyPwm = (value: number, presetId?: string, note?: string) => {
    const nextPwm = Math.round(clamp(value, 0, MAX_PWM));
    setPwm(nextPwm);
    setActivePreset(presetId ?? "custom");
    setLastPacket(note ?? "PWM command sent");
    pushHistory(nextPwm, ambientLight);
    sendToArduino(nextPwm);
  };

  const handlePreset = (preset: (typeof PRESETS)[number]) => {
    if (preset.id === "auto") {
      const next = !autoMode;
      setAutoMode(next);
      setActivePreset(next ? "auto" : "custom");
      setLastPacket(next ? "Auto mode following sensor" : "Auto mode off");
      if (next) applyPwm(Math.round((ambientLight / 100) * MAX_PWM), "auto", "Auto mode engaged");
      return;
    }
    setAutoMode(false);
    applyPwm(preset.pwm, preset.id, `${preset.label} preset applied`);
  };

  useEffect(() => {
    if (!autoMode) return;
    const target = Math.round(((100 - ambientLight) / 100) * MAX_PWM);
    setPwm(target);
    sendToArduino(target);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoMode, ambientLight]);

  const handlePowerToggle = () => {
    const nextPowered = !powered;
    setPowered(nextPowered);
    setLastPacket(nextPowered ? "Light output enabled" : "Light output disabled");
    sendToArduino(pwm, nextPowered);
  };

  const requestAdvice = async () => {
    if (!need.trim()) return;
    setAiLoading(true);
    setAiError("");
    try {
      const result = await askAi({ data: { need: need.trim() } });
      setAdvice(result);
    } catch (error) {
      setAiError(error instanceof Error ? error.message : "Could not get a suggestion.");
    } finally {
      setAiLoading(false);
    }
  };

  const activePresetHint =
    PRESETS.find((preset) => preset.id === activePreset)?.hint ?? "Custom level";

  return (
    <main className="min-h-screen bg-background text-foreground">
      <section className="relative isolate px-4 py-8 sm:px-6 lg:px-8">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_20%_10%,var(--color-glass),transparent_32%),radial-gradient(circle_at_78%_14%,color-mix(in_oklab,var(--primary)_22%,transparent),transparent_26%),linear-gradient(145deg,var(--color-background),var(--color-secondary))]" />

        <div className="mx-auto grid w-full max-w-6xl gap-8 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="order-2 space-y-6 lg:order-1">
            <div className="glass-surface rounded-[2rem] border p-5 shadow-[var(--shadow-soft)] sm:p-6">
              <div className="mb-6 flex items-center justify-between gap-4">
                <div>
                  <p className="text-sm font-bold uppercase text-muted-foreground">Arduino Bridge</p>
                  <h1 className="font-display text-3xl font-bold sm:text-4xl">Light Sensitivity</h1>
                  <p className="mt-1 text-xs font-semibold text-muted-foreground">
                    lightcontrollerserver.onrender.com
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <ThemeToggle theme={theme} onToggle={onToggleTheme} />
                  <Button variant="neoSoft" size="icon" onClick={onSignOut} aria-label="Sign out">
                    <LogOut className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-3">
                <Metric icon={Zap} label="PWM" value={pwm.toString()} detail="0-255" />
                <Metric icon={SunMedium} label="Sensitivity" value={`${percent}%`} detail="live level" />
                <Metric icon={Activity} label="Ambient" value={`${ambientLight}%`} detail="sensor" />
              </div>

              <div className="mt-5 flex items-center gap-2 text-xs font-bold text-muted-foreground">
                <Waves className="h-4 w-4 text-primary" aria-hidden="true" />
                {statusLabel} · {lastPacket}
              </div>
            </div>

            <div className="glass-surface rounded-[2rem] border p-5 shadow-[var(--shadow-soft)] sm:p-6">
              <div className="mb-4 flex items-center justify-between">
                <h2 className="font-display text-lg font-bold">PWM history</h2>
                <span className="text-xs font-bold text-muted-foreground">last {MAX_HISTORY} samples</span>
              </div>
              <div className="h-56 w-full">
                {history.length === 0 ? (
                  <div className="neo-sunken flex h-full items-center justify-center rounded-2xl text-xs font-bold text-muted-foreground">
                    Waiting for sensor data…
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={history} margin={{ top: 8, right: 8, bottom: 0, left: -20 }}>
                      <defs>
                        <linearGradient id="pwmFill" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="var(--color-primary)" stopOpacity={0.45} />
                          <stop offset="100%" stopColor="var(--color-primary)" stopOpacity={0.02} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid stroke="var(--color-border)" strokeDasharray="4 6" />
                      <XAxis
                        dataKey="time"
                        tick={{ fontSize: 10, fill: "var(--color-muted-foreground)" }}
                        interval="preserveStartEnd"
                      />
                      <YAxis
                        domain={[0, MAX_PWM]}
                        tick={{ fontSize: 10, fill: "var(--color-muted-foreground)" }}
                      />
                      <Tooltip
                        contentStyle={{
                          background: "var(--color-popover)",
                          border: "1px solid var(--color-border)",
                          borderRadius: "0.9rem",
                          color: "var(--color-popover-foreground)",
                          fontSize: "0.75rem",
                        }}
                      />
                      <Area
                        type="monotone"
                        dataKey="pwm"
                        stroke="var(--color-primary)"
                        strokeWidth={2}
                        fill="url(#pwmFill)"
                        name="PWM"
                        isAnimationActive={false}
                      />
                      <Area
                        type="monotone"
                        dataKey="ambient"
                        stroke="var(--color-accent)"
                        strokeWidth={2}
                        fill="none"
                        name="Ambient (scaled)"
                        isAnimationActive={false}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                )}
              </div>
            </div>

            <div className="glass-surface rounded-[2rem] border p-5 shadow-[var(--shadow-soft)] sm:p-6">
              <h2 className="font-display text-lg font-bold">AI light assistant</h2>
              <p className="mt-1 text-xs font-semibold text-muted-foreground">
                Describe your lighting need and get a recommended level.
              </p>
              <textarea
                value={need}
                onChange={(event) => setNeed(event.target.value)}
                rows={3}
                placeholder="Evening study session, warm and easy on the eyes"
                className="neo-sunken mt-3 w-full resize-none rounded-2xl border border-glass-border p-4 text-sm font-semibold outline-none focus:ring-2 focus:ring-ring"
              />
              <Button
                variant="neoActive"
                size="lg"
                className="mt-3 w-full"
                onClick={requestAdvice}
                disabled={aiLoading || !need.trim()}
              >
                {aiLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                ) : (
                  <Sparkles className="h-4 w-4" aria-hidden="true" />
                )}
                {aiLoading ? "Thinking…" : "Suggest a level"}
              </Button>

              {aiError ? (
                <p className="mt-3 text-sm font-semibold text-destructive">{aiError}</p>
              ) : null}

              {advice ? (
                <div className="neo-soft mt-4 rounded-2xl p-4">
                  <p className="text-xs font-extrabold uppercase text-muted-foreground">
                    {advice.label}
                  </p>
                  <p className="mt-1 text-2xl font-bold">
                    PWM {advice.pwm}{" "}
                    <span className="text-sm font-semibold text-muted-foreground">
                      ({Math.round((advice.pwm / MAX_PWM) * 100)}%)
                    </span>
                  </p>
                  <p className="mt-2 text-sm font-semibold text-muted-foreground">{advice.reason}</p>
                  <Button
                    variant="neoSoft"
                    size="sm"
                    className="mt-3"
                    onClick={() => {
                      setAutoMode(false);
                      applyPwm(advice.pwm, "custom", "AI level applied");
                    }}
                  >
                    Apply this level
                  </Button>
                </div>
              ) : null}
            </div>
          </div>

          <div className="order-1 flex justify-center lg:order-2">
            <div className="neo-panel animate-float-panel h-fit w-full max-w-sm rounded-[2.25rem] border border-glass-border p-5 sm:max-w-md sm:p-7">
              <div className="mb-7 flex items-center justify-between">
                <div>
                  <p className="text-xs font-extrabold uppercase text-muted-foreground">LumaSense</p>
                  <h2 className="font-display text-2xl font-bold">Smart Light</h2>
                </div>
                <span className="neo-soft inline-flex items-center gap-2 rounded-full px-3 py-2 text-xs font-extrabold">
                  <span
                    className={`h-2.5 w-2.5 rounded-full ${connection === "online" ? "animate-signal-pulse bg-success" : "bg-warning"}`}
                    aria-hidden="true"
                  />
                  {statusLabel}
                </span>
              </div>

              <div className="mb-8 grid grid-cols-5 gap-3">
                {PRESETS.map((preset) => (
                  <PresetButton
                    key={preset.id}
                    icon={preset.icon}
                    label={preset.label}
                    active={activePreset === preset.id}
                    onClick={() => handlePreset(preset)}
                  />
                ))}
              </div>

              <div className="mb-8 flex justify-center">
                <div
                  className="sensor-dial relative grid aspect-square w-56 place-items-center rounded-full p-8 sm:w-64"
                  style={{ "--level": percent } as React.CSSProperties}
                  aria-label={`PWM output ${pwm}`}
                >
                  <span className="absolute right-5 top-1/2 h-5 w-5 -translate-y-1/2 rounded-full bg-primary shadow-[var(--shadow-primary)]" />
                  <div className="sensor-dial-core grid h-full w-full place-items-center rounded-full bg-panel">
                    <div className="text-center">
                      <p className="font-display text-4xl font-semibold">{percent}%</p>
                      <p className="mt-1 text-xs font-bold uppercase text-muted-foreground">
                        PWM {pwm}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-end justify-between gap-3">
                  <div>
                    <p className="text-xs font-extrabold uppercase text-muted-foreground">
                      Light Sensitivity
                    </p>
                    <p className="text-lg font-bold">{activePresetHint}</p>
                  </div>
                  <Button
                    variant={powered ? "neoActive" : "neoSoft"}
                    size="icon"
                    onClick={handlePowerToggle}
                  >
                    <Lightbulb className="h-4 w-4" aria-hidden="true" />
                    <span className="sr-only">Toggle light output</span>
                  </Button>
                </div>

                <input
                  className="range-sensitivity w-full"
                  style={{ "--level": percent } as React.CSSProperties}
                  type="range"
                  min="0"
                  max={MAX_PWM}
                  value={pwm}
                  aria-label="Light sensitivity PWM slider"
                  onChange={(event) => {
                    setAutoMode(false);
                    applyPwm(Number(event.target.value));
                  }}
                />

                <div className="grid grid-cols-3 gap-3 pt-2 text-center">
                  <Reading label="Min" value="0" />
                  <Reading label="Live" value={lastPacket} strong />
                  <Reading label="Max" value="255" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}

function Metric({
  icon: Icon,
  label,
  value,
  detail,
}: {
  icon: typeof Gauge;
  label: string;
  value: string;
  detail: string;
}) {
  return (
    <div className="neo-soft rounded-3xl p-4">
      <Icon className="mb-4 h-5 w-5 text-primary" aria-hidden="true" />
      <p className="text-xs font-extrabold uppercase text-muted-foreground">{label}</p>
      <p className="mt-1 text-2xl font-bold">{value}</p>
      <p className="text-xs font-semibold text-muted-foreground">{detail}</p>
    </div>
  );
}

function PresetButton({
  icon: Icon,
  label,
  active,
  onClick,
}: {
  icon: typeof Lightbulb;
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <Button
      variant={active ? "neoActive" : "neoSoft"}
      className="h-auto min-w-0 flex-col px-2 py-3 text-[0.7rem]"
      onClick={onClick}
    >
      <Icon className="h-4 w-4" aria-hidden="true" />
      <span className="truncate">{label}</span>
    </Button>
  );
}

function Reading({ label, value, strong = false }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className="neo-soft min-h-16 rounded-2xl px-2 py-3">
      <p className="text-[0.65rem] font-extrabold uppercase text-muted-foreground">{label}</p>
      <p className={`mt-1 text-xs font-bold ${strong ? "text-primary" : "text-foreground"}`}>
        {value}
      </p>
    </div>
  );
}
