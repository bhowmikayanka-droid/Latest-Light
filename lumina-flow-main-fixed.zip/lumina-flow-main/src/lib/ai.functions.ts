import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const Input = z.object({ need: z.string().min(3).max(500) });

const Recommendation = z.object({
  pwm: z.number(),
  label: z.string(),
  reason: z.string(),
});

export type Recommendation = z.infer<typeof Recommendation>;

export const recommendSensitivity = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => Input.parse(input))
  .handler(async ({ data }): Promise<Recommendation> => {
    const key = process.env["LOVABLE_API_KEY"];
    if (!key) throw new Error("AI is not configured for this project.");

    const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Lovable-API-Key": key,
        "X-Lovable-AIG-SDK": "fetch",
      },
      body: JSON.stringify({
        model: "openai/gpt-6-astra",
        stream: true,
        reasoning: { effort: "low", summary: "auto" },
        include: ["reasoning.encrypted_content"],
        instructions:
          "You tune an Arduino light-sensitivity controller. PWM range is 0-255. Given the user's lighting need, pick one PWM value, a short preset label (max 3 words) and a one-sentence reason. Keep the reason under 30 words.",
        input: [
          {
            role: "user",
            content: [{ type: "input_text", text: data.need }],
          },
        ],
        text: {
          format: {
            type: "json_schema",
            name: "light_recommendation",
            strict: true,
            schema: {
              type: "object",
              additionalProperties: false,
              properties: {
                pwm: { type: "integer", minimum: 0, maximum: 255 },
                label: { type: "string" },
                reason: { type: "string" },
              },
              required: ["pwm", "label", "reason"],
            },
          },
        },
      }),
    });

    if (!res.ok || !res.body) {
      const detail = await res.text().catch(() => "");
      if (res.status === 429) throw new Error("AI is busy right now — try again in a moment.");
      if (res.status === 402) throw new Error("AI credits are used up for this workspace.");
      throw new Error(`AI request failed (${res.status}). ${detail.slice(0, 200)}`);
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let text = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        if (!line.startsWith("data:")) continue;
        const payload = line.slice(5).trim();
        if (!payload || payload === "[DONE]") continue;
        try {
          const event = JSON.parse(payload) as {
            type?: string;
            delta?: string;
            response?: { output_text?: string };
          };
          if (event.type === "response.output_text.delta" && typeof event.delta === "string") {
            text += event.delta;
          } else if (event.type === "response.completed" && event.response?.output_text) {
            if (!text) text = event.response.output_text;
          }
        } catch {
          // ignore keep-alive / partial frames
        }
      }
    }

    if (!text.trim()) throw new Error("The AI did not return a recommendation. Please try again.");

    const parsed = Recommendation.parse(JSON.parse(text));
    return {
      ...parsed,
      pwm: Math.max(0, Math.min(255, Math.round(parsed.pwm))),
    };
  });
